package com.example.milkspill

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.min
import kotlin.random.Random

data class Drop(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var r: Float,
    var life: Float
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0F1115)) {
                    MilkSpillScreen()
                }
            }
        }
    }
}

@Composable
fun MilkSpillScreen() {
    val context = LocalContext.current

    var tiltX by remember { mutableFloatStateOf(0f) } // left/right
    var tiltY by remember { mutableFloatStateOf(0f) } // forward/back (not heavily used)

    // Read accelerometer
    DisposableEffect(Unit) {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        val listener = object : SensorEventListener {
            private var sx = 0f
            private var sy = 0f
            override fun onSensorChanged(event: SensorEvent) {
                // low-pass filter for smooth tilt
                val alpha = 0.15f
                sx += alpha * (event.values[0] - sx)
                sy += alpha * (event.values[1] - sy)
                tiltX = sx
                tiltY = sy
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }

        sm.registerListener(listener, accel, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm.unregisterListener(listener) }
    }

    val drops = remember { mutableStateListOf<Drop>() }

    // Spill trigger
    val spillThreshold = 4.2f
    val spillStrength = (abs(tiltX) - spillThreshold).coerceAtLeast(0f)
    val isSpilling = spillStrength > 0f

    // Basic “time step”
    var lastNanos by remember { mutableLongStateOf(0L) }

    Canvas(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        // timing
        val now = System.nanoTime()
        val dt = if (lastNanos == 0L) 0f else ((now - lastNanos) / 1_000_000_000f).coerceIn(0f, 0.033f)
        lastNanos = now

        // Glass layout
        val w = size.width
        val h = size.height

        val glassW = min(w * 0.55f, 520f)
        val glassH = min(h * 0.60f, 760f)

        val glassLeft = (w - glassW) / 2f
        val glassTop = (h - glassH) / 2f
        val glassRight = glassLeft + glassW
        val glassBottom = glassTop + glassH

        // Milk level and tilt surface
        val fill = 0.70f
        val milkTop = glassBottom - glassH * fill

        // Convert tilt to a gentle surface slope
        val slope = (-tiltX / 9.8f).coerceIn(-0.45f, 0.45f)
        val surfaceDelta = slope * (glassW * 0.30f)

        // Glass outline
        drawRoundRect(
            color = Color(0xFFB7C0CC),
            topLeft = Offset(glassLeft, glassTop),
            size = Size(glassW, glassH),
            cornerRadius = CornerRadius(28f, 28f),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 10f)
        )

        // Milk shape
        val milkPath = Path().apply {
            val leftX = glassLeft + 10f
            val rightX = glassRight - 10f
            val topYLeft = milkTop + surfaceDelta
            val topYRight = milkTop - surfaceDelta

            moveTo(leftX, glassBottom - 10f)
            lineTo(leftX, topYLeft)
            lineTo(rightX, topYRight)
            lineTo(rightX, glassBottom - 10f)
            close()
        }
        drawPath(milkPath, color = Color(0xFFF3F4F6))

        // If spilling: spawn drops near the rim on the lower side
        if (isSpilling && dt > 0f) {
            val rimX = if (tiltX > 0) glassLeft + 22f else glassRight - 22f
            val rimY = milkTop + if (tiltX > 0) surfaceDelta else -surfaceDelta

            val spawnCount = (spillStrength * 10f).coerceIn(1f, 10f).toInt()
            repeat(spawnCount) {
                val vx = (if (tiltX > 0) -1 else 1) * Random.nextFloat() * (350f + spillStrength * 220f)
                val vy = -Random.nextFloat() * (220f + spillStrength * 120f)
                drops.add(
                    Drop(
                        x = rimX + Random.nextFloat() * 10f - 5f,
                        y = rimY + Random.nextFloat() * 10f - 5f,
                        vx = vx,
                        vy = vy,
                        r = Random.nextFloat() * 8f + 6f,
                        life = Random.nextFloat() * 1.2f + 0.8f
                    )
                )
            }
            while (drops.size > 220) drops.removeAt(0)
        }

        // Update drops
        if (dt > 0f) {
            val g = 2200f
            val drag = 0.985f

            for (d in drops) {
                d.vx *= drag
                d.vy = (d.vy + g * dt) * drag
                d.x += d.vx * dt
                d.y += d.vy * dt
                d.life -= dt
            }
            drops.removeAll { it.life <= 0f || it.y > h + 200f }
        }

        // Draw drops
        for (d in drops) {
            drawCircle(
                color = Color(0xFFF3F4F6),
                radius = d.r,
                center = Offset(d.x, d.y)
            )
        }

        // Glass shine line
        drawLine(
            color = Color(0x66FFFFFF),
            start = Offset(glassLeft + glassW * 0.25f, glassTop + glassH * 0.12f),
            end = Offset(glassLeft + glassW * 0.18f, glassBottom - glassH * 0.12f),
            strokeWidth = 6f,
            cap = androidx.compose.ui.graphics.StrokeCap.Round
        )
    }
}
