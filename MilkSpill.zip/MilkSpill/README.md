# MilkSpill (Tilt-to-spill demo)

Upload this repo to GitHub. GitHub Actions builds a debug APK on every push to `main`.

Download the APK:
Repo → Actions → latest workflow run → Artifacts → `app-debug-apk` → `app-debug.apk`

If you want a signed release APK/AAB, you can extend the workflow with keystore secrets.
